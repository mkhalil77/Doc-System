﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dental_app
{
    public partial class Ajout_charges_fix : Form
    {
        public Ajout_charges_fix()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            string constring = "datasource=localhost;port=3306;username=root;password=BITEme4789";
            MySqlConnection conDataBase = new MySqlConnection(constring);
            MySqlCommand cmdDataBase = new MySqlCommand("select * from dentaldb.charge_usuelle ;", conDataBase);

            try
            {
                MySqlDataAdapter sda = new MySqlDataAdapter();
                sda.SelectCommand = cmdDataBase;
                DataTable dbdataset = new DataTable();
                sda.Fill(dbdataset);
                BindingSource bSource = new BindingSource();

                bSource.DataSource = dbdataset;
                dataGridView1.DataSource = bSource;
                sda.Update(dbdataset);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            // ajout_charge_usuelle

            try
            {

                string myConnection3 = "datasource=localhost;port=3306;username=root;password=BITEme4789";
                string query3 = "insert into dentaldb.charge_usuelle values (0,'" + this.textBox4.Text + "','" + this.textBox5.Text + "');";

                MySqlConnection myConn3 = new MySqlConnection(myConnection3);
                MySqlCommand cmdDataBase3 = new MySqlCommand(query3, myConn3);
                MySqlDataReader myReader3;

                myConn3.Open();
                myReader3 = cmdDataBase3.ExecuteReader();
                MessageBox.Show("Charge usuelle ajoutée avec succès!!");

                while (myReader3.Read()) { }

            }
            catch (Exception ex)
            { MessageBox.Show(ex.Message); }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult myResult;
            myResult = MessageBox.Show("Etes vous sur de vouloir supprimer cette charge?", "Delete Confirmation", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
            if (myResult == DialogResult.OK)
            {

                string constring = "datasource=localhost;port=3306;username=root;password=BITEme4789";

                if (dataGridView1.SelectedRows.Count > 0)
                {
                    int selectedIndex = dataGridView1.SelectedRows[0].Index;

                    // gets the RowID from the first column in the grid
                    int rowID = int.Parse(dataGridView1[0, selectedIndex].Value.ToString());

                    string sql = "DELETE FROM dentaldb.charge_usuelle WHERE id_charge_us=" + rowID + ";";
                    MySqlConnection conDataBase = new MySqlConnection(constring);
                    MySqlCommand cmdDataBase = new MySqlCommand(sql, conDataBase);
                    MySqlDataReader myReader;
                    try
                    {
                        conDataBase.Open();
                        myReader = cmdDataBase.ExecuteReader();
                        MessageBox.Show("charge usuelle supprimée !! ");
                        while (myReader.Read())
                        { }
                    }
                    catch (Exception ex)
                    { MessageBox.Show(ex.Message); }

                    dataGridView1.Rows.RemoveAt(this.dataGridView1.SelectedRows[0].Index);
                }


            }
            else
            {
                //No delete
            }

        }
    }
}
