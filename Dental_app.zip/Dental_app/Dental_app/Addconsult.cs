﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dental_app
{
    public partial class Addconsult : Form
    {
        private float prix_acte;
        private float taux_reduction = 0f;
        private int id_acte;

        public Addconsult(int Id_value)
        {
            InitializeComponent();
            FillCombo();
            
            id_pat_vis.Text = Id_value.ToString();
        }

        private void button23_Click(object sender, EventArgs e)
        {
            // ajouter consultation
            try
            {
                string myConnection1 = "datasource=localhost;port=3306;username=root;password=BITEme4789";
                string query1 = "select * from dentaldb.acte  where libelle_acte='" + comboBox1.Text + "' ; ";


                MySqlConnection myConn1 = new MySqlConnection(myConnection1);
                MySqlCommand cmdDataBase1 = new MySqlCommand(query1, myConn1);
                MySqlDataReader myReader1;

                myConn1.Open();
                myReader1 = cmdDataBase1.ExecuteReader();


                while (myReader1.Read())
                {
                    this.id_acte = Int16.Parse(myReader1.GetString("NUM_ACTE"));
                }

            }

            catch (Exception ex)
            { MessageBox.Show(ex.Message); }

            try
            {
                string myConnection1 = "datasource=localhost;port=3306;username=root;password=BITEme4789";
                string query1 = "insert into dentaldb.consultation values (0,'" + this.id_pat_vis.Text + "','" + this.id_acte + "','" + this.dateTimePicker1.Text + "','" + this.dent.Text + "','" + this.traitement.Text + "','" + this.reduction.Text + "','" + this.total_paye.Text + "','" + this.reste.Text + "'  );  ";

                // string query2 = "select max(id_pat) from cabinet_medical.patient where nom_pat='" + this.nv_rdv_nom.Text + "' and prenom_pat='" + this.nv_rdv_prenom.Text + "'; ";

                MySqlConnection myConn1 = new MySqlConnection(myConnection1);
                MySqlCommand cmdDataBase1 = new MySqlCommand(query1, myConn1);
                MySqlDataReader myReader1;

                myConn1.Open();
                myReader1 = cmdDataBase1.ExecuteReader();


                while (myReader1.Read()) { }
            }
            catch (Exception ex1)
            { MessageBox.Show(ex1.Message); }

            MessageBox.Show("Consultation ajoutée avec succès !! ");
            this.Hide();
        }
        void FillCombo()
        {
            string myConnection2 = "datasource=localhost;port=3306;username=root;password=BITEme4789";
            string query2 = "select * from dentaldb.acte ; ";

            try
            {

                MySqlConnection myConn2 = new MySqlConnection(myConnection2);
                MySqlCommand cmdDataBase2 = new MySqlCommand(query2, myConn2);
                MySqlDataReader myReader2;

                myConn2.Open();
                myReader2 = cmdDataBase2.ExecuteReader();


                while (myReader2.Read())
                {

                    string acte = myReader2.GetString("LIBELLE_ACTE");
                    comboBox1.Items.Add(acte);
                }

            }

            catch (Exception ex)
            { MessageBox.Show(ex.Message); }

        }
        private void button10_Click(object sender, EventArgs e)
        {
            // calcul total 
            if (string.IsNullOrWhiteSpace(reduction.Text))
            {
                this.taux_reduction = 0.0f;

            }
            else
            {

                this.taux_reduction = float.Parse(reduction.Text);
            }

            try
            {
                string myConnection = "datasource=localhost;port=3306;username=root;password=BITEme4789";
                string query = "select * from dentaldb.acte  where libelle_acte='" + comboBox1.Text + "' ; ";


                MySqlConnection myConn = new MySqlConnection(myConnection);
                MySqlCommand cmdDataBase = new MySqlCommand(query, myConn);
                MySqlDataReader myReader;

                myConn.Open();
                myReader = cmdDataBase.ExecuteReader();


                while (myReader.Read())
                {
                    this.prix_acte = float.Parse(myReader.GetString("PRIX_ACTE"));
                }

            }

            catch (Exception ex)
            { MessageBox.Show(ex.Message); }


            this.total_a_payer.Text = (prix_acte - (prix_acte * taux_reduction / 100)).ToString();
        
        }

        private void button22_Click(object sender, EventArgs e)
        {
            //calculer reste 

            float prix = float.Parse(this.total_a_payer.Text) - float.Parse(this.total_paye.Text);

            this.reste.Text = prix.ToString();

        }

        private void button27_Click(object sender, EventArgs e)
        {
            Form form = new Teeth();
            form.Show();
        
        }

        private void Addconsult_Load(object sender, EventArgs e)
        {
            
        }
    }
}
