﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dental_app
{
    public partial class MAJ_RDV : Form
    {
        private int id_rdv;
        private int id_pat;
        private string date_rdv;

        private DateTime datetime_rdv;

        private string heure_rdv;
        private string com;
        //private string coment;
        private string nom_rdv;
        private string prenom_rdv;
        private string tel_pat;
        //private string heure_rdv3;

        public MAJ_RDV(int id)
        {
            InitializeComponent();
            id_rdv = id;

            try
            {
               
                string myConnection2 = "datasource=localhost;port=3306;username=root;password=BITEme4789";
                string query2 = "select id_pat,date_rdv,heure_rdv,commentaire from dentaldb.rdv where id_rdv='" + id_rdv + "'; ";



                MySqlConnection myConn2 = new MySqlConnection(myConnection2);
                MySqlCommand cmdDataBase2 = new MySqlCommand(query2, myConn2);
                MySqlDataReader myReader2;

                myConn2.Open();
                myReader2 = cmdDataBase2.ExecuteReader();


                while (myReader2.Read())
                {

                    id_pat = (int)myReader2["id_pat"];
                    datetime_rdv= (DateTime)myReader2["date_rdv"] ;
                    heure_rdv = (string)myReader2["heure_rdv"];
                    com = (string)myReader2["commentaire"];

                }
            }
            catch (Exception ex)
            { MessageBox.Show(ex.Message); }




            try
            {
                string myConnection1 = "datasource=localhost;port=3306;username=root;password=BITEme4789";
                string query1 = "select nom_pat,prenom_pat,num_tel_pat from dentaldb.patient where id_pat='" + id_pat + "'; ";



                MySqlConnection myConn1 = new MySqlConnection(myConnection1);
                MySqlCommand cmdDataBase1 = new MySqlCommand(query1, myConn1);
                MySqlDataReader myReader1;

                myConn1.Open();
                myReader1 = cmdDataBase1.ExecuteReader();


                while (myReader1.Read())
                {

                    nom_rdv = (string)myReader1["nom_pat"];
                    prenom_rdv = (string)myReader1["prenom_pat"];
                    tel_pat = (string)myReader1["num_tel_pat"];

                }
            }
            catch (Exception ex)
            { MessageBox.Show(ex.Message); }

            this.textBox1.ReadOnly = true;
            this.textBox2.ReadOnly = true;
            this.textBox3.ReadOnly = true;

            this.textBox1.Text = nom_rdv;
            this.textBox2.Text = prenom_rdv;
            this.textBox3.Text = tel_pat;
            this.dateTimePicker1.Text = datetime_rdv.ToString("yyyy-MM-dd");
            this.dateTimePicker2.Text = heure_rdv;
            this.textBox6.Text = com;

            InitializeComponent();

            
        }

        private void button1_Click(object sender, EventArgs e)
        {

            // mettre RDV a jour 


            int boolean = 0;

            date_rdv = this.dateTimePicker1.Text;
            heure_rdv = this.dateTimePicker2.Text;
            string date_convertie;
            DateTime date_lue;


            try
            {
                string myConnection2 = "datasource=localhost;port=3306;username=root;password=BITEme4789";
                string query2 = "select date_rdv,heure_rdv from dentaldb.rdv; ";

                MySqlConnection myConn2 = new MySqlConnection(myConnection2);
                MySqlCommand cmdDataBase2 = new MySqlCommand(query2, myConn2);
                MySqlDataReader myReader2;

                myConn2.Open();
                myReader2 = cmdDataBase2.ExecuteReader();


                while (myReader2.Read() && boolean == 0)
                {

                    date_lue = (DateTime)myReader2["date_rdv"];
                    date_convertie = date_lue.ToString("yyyy-MM-dd");


                    if (date_rdv.Equals(date_convertie) && heure_rdv.Equals((string)myReader2["heure_rdv"]))
                    { boolean = 1; }

                }

            }
            catch (Exception ex)
            { MessageBox.Show(ex.Message); }


            if (boolean == 1)

            { MessageBox.Show("Entrer une autre date, ce RDv est déja pris !!"); }

            else
            {

                string constring = "datasource=localhost;port=3306;username=root;password=BITEme4789";
                string sql = "update dentaldb.rdv set date_rdv='" + this.dateTimePicker1.Text + "',heure_rdv='" + this.dateTimePicker2.Text + "' ,commentaire='" + this.textBox6.Text + "' where id_rdv=" + id_rdv + "  ;";
                MySqlConnection conDataBase = new MySqlConnection(constring);
                MySqlCommand cmdDataBase = new MySqlCommand(sql, conDataBase);
                MySqlDataReader myReader;
                try
                {
                    conDataBase.Open();
                    myReader = cmdDataBase.ExecuteReader();
                    MessageBox.Show("RDV mis à jour !! ");
                    while (myReader.Read())
                    { }
                }

                catch (Exception ex)
                { MessageBox.Show(ex.Message); }




            }
            /*
            // mettre RDV a jour 


            int boolean = 0;

            date_rdv = this.dateTimePicker1.Text;
            heure_rdv3 = this.dateTimePicker2.Text;
            coment = this.textBox6.Text;
            string date_convertie;
            DateTime date_lue;


            try
            {
                string myConnection2 = "datasource=localhost;port=3306;username=root;password=BITEme4789";
                string query2 = "select date_rdv,heure_rdv from dentaldb.rdv; ";

                MySqlConnection myConn2 = new MySqlConnection(myConnection2);
                MySqlCommand cmdDataBase2 = new MySqlCommand(query2, myConn2);
                MySqlDataReader myReader2;

                myConn2.Open();
                myReader2 = cmdDataBase2.ExecuteReader();


                while (myReader2.Read() && boolean == 0)
                {

                    date_lue = (DateTime)myReader2["date_rdv"];
                    date_convertie = date_lue.ToString("yyyy-MM-dd");


                    if (date_rdv.Equals(date_convertie) && heure_rdv.Equals((string)myReader2["heure_rdv"]))
                    { boolean = 1; }

                }

            }
            catch (Exception ex)
            { MessageBox.Show(ex.Message); }


            if (boolean == 1)

            { MessageBox.Show("Entrer une autre date, ce RDv est déja pris !!"); }

            else
            {

                string constring = "datasource=localhost;port=3306;username=root;password=BITEme4789";
                string sql = "update dentaldb.rdv set date_rdv='" + date_rdv + "',heure_rdv='" + heure_rdv3 + "' ,commentaire='" + coment + "' where id_rdv=" + id_rdv + "  ;";
                MySqlConnection conDataBase = new MySqlConnection(constring);
                MySqlCommand cmdDataBase = new MySqlCommand(sql, conDataBase);
                MySqlDataReader myReader;
                try
                {
                    conDataBase.Open();
                    myReader = cmdDataBase.ExecuteReader();
                    MessageBox.Show("RDV mis à jour !! ");
                    this.Hide();
                    while (myReader.Read())
                    { }
                }

                catch (Exception ex)
                { MessageBox.Show(ex.Message); }
            
            }*/
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}
