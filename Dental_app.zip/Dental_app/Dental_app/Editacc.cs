﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Dental_app
{
    public partial class Editacc : Form
    {
        public static int id3;
        public Editacc(int id)
        {
            id3 = id;
            InitializeComponent();

            try
            {
                string myConnection2 = "datasource=localhost;port=3306;username=root;password=BITEme4789";
                string query2 = "select * from dentaldb.auth where idAuth='" + id + "'; ";



                MySqlConnection myConn2 = new MySqlConnection(myConnection2);
                MySqlCommand cmdDataBase2 = new MySqlCommand(query2, myConn2);
                MySqlDataReader myReader2;

                myConn2.Open();
                myReader2 = cmdDataBase2.ExecuteReader();


                while (myReader2.Read())
                {

                    logmod.Text = (string)myReader2["user_name"];
                    passmod.Text = (string)myReader2["password"];

                }
            }
            catch (Exception ex)
            { MessageBox.Show(ex.Message); }
        }

        private void Ajouter_Click(object sender, EventArgs e)
        {
            string constring = "datasource=localhost;port=3306;username=root;password=BITEme4789";
            string Query = "update dentaldb.auth set user_name='" + this.logmod.Text + "',password='" + this.passmod.Text + "' where idAuth= " + id3 + " ;";
            MySqlConnection conDataBase = new MySqlConnection(constring);
            MySqlCommand cmdDataBase = new MySqlCommand(Query, conDataBase);
            MySqlDataReader myReader;
            try
            {
                conDataBase.Open();
                myReader = cmdDataBase.ExecuteReader();
                MessageBox.Show("Saved");
                this.Hide();
                while (myReader.Read())
                {

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

    }
}
