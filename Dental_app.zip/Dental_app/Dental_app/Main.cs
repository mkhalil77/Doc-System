﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dental_app
{

    public partial class Main : Form
    {
        public static int id2;
        string type_date;
        string start = "0";
        string end = "0";
        string date = "0";

        public static int idid;
            
        public Main(string Str_value)
        {
            InitializeComponent();
            
            user_welcome_lbl.Text = Str_value;
        }

        

        private void button6_Click(object sender, EventArgs e)
        {
            this.Hide();
            auth sss = new auth();
            sss.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("calc");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPat;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabrdv;
        }

        private void button10_Click(object sender, EventArgs e)
        {

            String constring = "datasource=localhost;port=3306;username=root;password=BITEme4789";
            MySqlConnection conDataBase = new MySqlConnection(constring);
            MySqlCommand cmdDataBase = new MySqlCommand("select * from dentaldb.patient ;", conDataBase);

            try
            {
                MySqlDataAdapter sda = new MySqlDataAdapter();
                sda.SelectCommand = cmdDataBase;
                DataTable dbdataset = new DataTable();
                sda.Fill(dbdataset);
                BindingSource bSource = new BindingSource();

                bSource.DataSource = dbdataset;
                dataGridView3.DataSource = bSource;
                sda.Update(dbdataset);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void button7_Click(object sender, EventArgs e)
        {
            addpat sa = new addpat();
            sa.ShowDialog();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            //modifier patient

            if (dataGridView3.SelectedRows.Count > 0) {
                int selectedIndex = dataGridView3.SelectedRows[0].Index;

                int rowID = int.Parse(dataGridView3[0, selectedIndex].Value.ToString());
                mofpat sm = new mofpat(rowID);
                sm.ShowDialog();
            }
            
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button9_Click(object sender, EventArgs e)
        {
            //supprimer patient

            if (dataGridView3.SelectedRows.Count > 0) {
                int selectedIndex = dataGridView3.SelectedRows[0].Index;

                int rowID = int.Parse(dataGridView3[0, selectedIndex].Value.ToString());
                id2 = rowID;
            }
            try
            {
                string myConnection2 = "datasource=localhost;port=3306;username=root;password=BITEme4789";
                string query2 = "delete from dentaldb.patient where ID_PAT='" + id2 + "'; ";


                MySqlConnection myConn2 = new MySqlConnection(myConnection2);
                MySqlCommand cmdDataBase2 = new MySqlCommand(query2, myConn2);
                MySqlDataReader myReader2;

                myConn2.Open();
                myReader2 = cmdDataBase2.ExecuteReader();

            }
            catch (Exception ex)
            { MessageBox.Show(ex.Message); }

            dataGridView3.Rows.RemoveAt(this.dataGridView3.SelectedRows[0].Index);
        }

        private void button15_Click(object sender, EventArgs e)
        {
            // RDV d'aujourdh'ui 

            DateTime today = DateTime.Today;

            // Console.WriteLine(today.ToString("yyyy-MM-dd"));


            string constring = "datasource=localhost;port=3306;username=root;password=BITEme4789";
            MySqlConnection conDataBase = new MySqlConnection(constring);
            MySqlCommand cmdDataBase = new MySqlCommand("select R.id_rdv,P.cin_pat,P.nom_pat,P.prenom_pat,P.num_tel_pat,R.date_rdv,R.heure_rdv,R.commentaire from dentaldb.patient P,dentaldb.rdv R where P.id_pat=R.id_pat and R.date_rdv='" + today.ToString("yyyy-MM-dd") + "' ;", conDataBase);

            try
            {
                MySqlDataAdapter sda = new MySqlDataAdapter();
                sda.SelectCommand = cmdDataBase;
                DataTable dbdataset = new DataTable();
                sda.Fill(dbdataset);
                BindingSource bSource = new BindingSource();

                bSource.DataSource = dbdataset;
                dataGridView2.DataSource = bSource;
                sda.Update(dbdataset);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button18_Click(object sender, EventArgs e)
        {
            // annuler un RDV 

            DialogResult myResult;
            myResult = MessageBox.Show("Etes vous sur de vouloir supprimer ce RDV?", "Delete Confirmation", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
            if (myResult == DialogResult.OK)
            {

                string constring = "datasource=localhost;port=3306;username=root;password=BITEme4789";

                if (dataGridView2.SelectedRows.Count > 0)
                {
                    int selectedIndex = dataGridView2.SelectedRows[0].Index;

                    // gets the RowID from the first column in the grid
                    int rowID = int.Parse(dataGridView2[0, selectedIndex].Value.ToString());

                    string sql = "DELETE FROM dentaldb.rdv WHERE id_rdv=" + rowID + ";";
                    MySqlConnection conDataBase = new MySqlConnection(constring);
                    MySqlCommand cmdDataBase = new MySqlCommand(sql, conDataBase);
                    MySqlDataReader myReader;
                    try
                    {
                        conDataBase.Open();
                        myReader = cmdDataBase.ExecuteReader();
                        MessageBox.Show("RDV(s) annulé !! ");
                        while (myReader.Read())
                        { }
                    }
                    catch (Exception ex)
                    { MessageBox.Show(ex.Message); }

                    dataGridView2.Rows.RemoveAt(this.dataGridView2.SelectedRows[0].Index);
                }


            }
            else
            {
                //No delete
            }
        }

        private void button14_Click(object sender, EventArgs e)
        {
            if (dataGridView3.SelectedRows.Count > 0)
            {
                int selectedIndex = dataGridView3.SelectedRows[0].Index;
            
                int rdv_val = int.Parse(dataGridView3[0, selectedIndex].Value.ToString());
                string cin_val = dataGridView3.SelectedRows[0].Cells[1].Value.ToString();
                Form form = new Ajouter_RDV(cin_val);
                form.ShowDialog();
            }
         
        }

        private void button13_Click(object sender, EventArgs e)
        {
            //recherche RDV par nom+prenom

            string nom_recherche = this.nom_rech.Text;
            string prenom_recherche = this.prenom_rech.Text;


            string constring = "datasource=localhost;port=3306;username=root;password=BITEme4789";
            MySqlConnection conDataBase = new MySqlConnection(constring);
            MySqlCommand cmdDataBase = new MySqlCommand("select R.id_rdv,P.cin_pat,P.nom_pat,P.prenom_pat,P.num_tel_pat,R.date_rdv,R.heure_rdv,R.commentaire from dentaldb.patient P,dentaldb.rdv R where P.id_pat=R.id_pat and P.nom_pat='" + nom_recherche + "' and P.prenom_pat='" + prenom_recherche + "' ;", conDataBase);

            try
            {
                MySqlDataAdapter sda = new MySqlDataAdapter();
                sda.SelectCommand = cmdDataBase;
                DataTable dbdataset = new DataTable();
                sda.Fill(dbdataset);
                BindingSource bSource = new BindingSource();

                bSource.DataSource = dbdataset;
                dataGridView2.DataSource = bSource;
                sda.Update(dbdataset);
                nom_rech.Clear();
                prenom_rech.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            type_date = "par_jours";
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            type_date = "par_intervalle";
        }

        private void monthCalendar1_DateChanged(object sender, DateRangeEventArgs e)
        {
            // MessageBox.Show("DateChanged: " + monthCalendar1.SelectionRange.Start.ToString("yyyy-MM-dd"));



            if (type_date == "par_intervalle")
            {

                start = monthCalendar1.SelectionStart.ToString("yyyy-MM-dd");
                end = monthCalendar1.SelectionEnd.ToString("yyyy-MM-dd");

            }


            if (type_date == "par_jours")
            {
                date = monthCalendar1.SelectionRange.Start.ToString("yyyy-MM-dd");
            }

        }

        private void button11_Click(object sender, EventArgs e)
        {
            if (type_date == "par_jours")
            {
                string constring = "datasource=localhost;port=3306;username=root;password=BITEme4789";
                MySqlConnection conDataBase = new MySqlConnection(constring);
                MySqlCommand cmdDataBase = new MySqlCommand("select R.id_rdv,P.cin_pat,P.nom_pat,P.prenom_pat,P.num_tel_pat,R.date_rdv,R.heure_rdv,R.commentaire from dentaldb.patient P,dentaldb.rdv R where P.id_pat=R.id_pat and R.date_rdv='" + date + "' ;", conDataBase);

                try
                {
                    MySqlDataAdapter sda = new MySqlDataAdapter();
                    sda.SelectCommand = cmdDataBase;
                    DataTable dbdataset = new DataTable();
                    sda.Fill(dbdataset);
                    BindingSource bSource = new BindingSource();

                    bSource.DataSource = dbdataset;
                    dataGridView2.DataSource = bSource;
                    sda.Update(dbdataset);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }

            if (type_date == "par_intervalle")
            {

                start = monthCalendar1.SelectionStart.ToString("yyyy-MM-dd");
                end = monthCalendar1.SelectionEnd.ToString("yyyy-MM-dd");


                //MessageBox.Show(start + " " + end);




                string constring = "datasource=localhost;port=3306;username=root;password=BITEme4789";
                MySqlConnection conDataBase = new MySqlConnection(constring);
                MySqlCommand cmdDataBase = new MySqlCommand("select P.nom_pat,P.prenom_pat,P.num_tel_pat,R.date_rdv,R.heure_rdv,R.commentaire from dentaldb.patient P,dentaldb.rdv R where P.id_pat=R.id_pat and R.date_rdv <='" + end + "' and R.date_rdv >='" + start + "';", conDataBase);

                try
                {
                    MySqlDataAdapter sda = new MySqlDataAdapter();
                    sda.SelectCommand = cmdDataBase;
                    DataTable dbdataset = new DataTable();
                    sda.Fill(dbdataset);
                    BindingSource bSource = new BindingSource();

                    bSource.DataSource = dbdataset;
                    dataGridView2.DataSource = bSource;
                    sda.Update(dbdataset);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }


            }
        }

        private void button16_Click(object sender, EventArgs e)
        {
            string constring = "datasource=localhost;port=3306;username=root;password=BITEme4789";
            MySqlConnection conDataBase = new MySqlConnection(constring);
            MySqlCommand cmdDataBase = new MySqlCommand("select R.id_rdv,P.cin_pat,P.nom_pat,P.prenom_pat,P.num_tel_pat,R.date_rdv,R.heure_rdv,R.commentaire from dentaldb.patient P,dentaldb.rdv R where P.id_pat=R.id_pat ;", conDataBase);

            try
            {
                MySqlDataAdapter sda = new MySqlDataAdapter();
                sda.SelectCommand = cmdDataBase;
                DataTable dbdataset = new DataTable();
                sda.Fill(dbdataset);
                BindingSource bSource = new BindingSource();

                bSource.DataSource = dbdataset;
                dataGridView2.DataSource = bSource;
                sda.Update(dbdataset);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button17_Click(object sender, EventArgs e)
        {
            // mettre un RDV a jour 


            if (dataGridView2.SelectedRows.Count > 0)
            {
                int selectedIndex = dataGridView2.SelectedRows[0].Index;

                // gets the RowID from the first column in the grid
                int rowID = int.Parse(dataGridView2[0, selectedIndex].Value.ToString());

                // this.Hide();
                Form form = new MAJ_RDV(rowID);
                form.Show();
            }
        }

        private void button12_Click(object sender, EventArgs e)
        {
            //recherche par CIN

            string cin_recherche = this.textBox1.Text;

            string constring = "datasource=localhost;port=3306;username=root;password=BITEme4789";
            MySqlConnection conDataBase = new MySqlConnection(constring);
            MySqlCommand cmdDataBase = new MySqlCommand("select R.id_rdv,P.cin_pat,P.nom_pat,P.prenom_pat,P.num_tel_pat,R.date_rdv,R.heure_rdv,R.commentaire from dentaldb.patient P,dentaldb.rdv R where P.id_pat=R.id_pat and P.cin_pat='" + cin_recherche + "' ;", conDataBase);

            try
            {
                MySqlDataAdapter sda = new MySqlDataAdapter();
                sda.SelectCommand = cmdDataBase;
                DataTable dbdataset = new DataTable();
                sda.Fill(dbdataset);
                BindingSource bSource = new BindingSource();

                bSource.DataSource = dbdataset;
                dataGridView2.DataSource = bSource;
                sda.Update(dbdataset);
                textBox1.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button19_Click(object sender, EventArgs e)
        {
            
        }

       
        private void button5_Click(object sender, EventArgs e)
        {
            Form form = new acounts();
            form.Show();

        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button21_Click(object sender, EventArgs e)
        {
            dataGridView3.AllowUserToAddRows = false;
            String constring = "datasource=localhost;port=3306;username=root;password=BITEme4789";
            MySqlConnection conDataBase = new MySqlConnection(constring);
            MySqlCommand cmdDataBase = new MySqlCommand("select * from dentaldb.patient ;", conDataBase);

            try
            {
                MySqlDataAdapter sda = new MySqlDataAdapter();
                sda.SelectCommand = cmdDataBase;
                DataTable dbdataset = new DataTable();
                sda.Fill(dbdataset);
                BindingSource bSource = new BindingSource();

                bSource.DataSource = dbdataset;
                dataGridView3.DataSource = bSource;
                sda.Update(dbdataset);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void dataGridView3_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }

        private void button19_Click_1(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = Consultation;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView3_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //id = Convert.ToInt32(dataGridView3.Rows[e.RowIndex].Cells["id"].Value.ToString());
            
            
            //MySqlCommand cmd = con.CreateCommand();
            
        }

        private void Main_Load(object sender, EventArgs e)
        {

            timelbl.Text = DateTime.Now.ToLongTimeString();
            
            /*MySqlConnection con = new MySqlConnection("Data Source=(localdb)/Projects;Initial Catalog=master;Integrated Security=True;");
            MySqlDataAdapter SDA = new MySqlDataAdapter("select * from dentaldb.patient ;", con);
            DataTable dt = new DataTable();
            SDA.Fill(dt);
            dataGridView3.DataSource = dt;
            */
            
            

            /*    //  ******************this is load like********************* 
            dataGridView3.AllowUserToAddRows = false;
            String constring = "datasource=localhost;port=3306;username=root;password=BITEme4789";
            MySqlConnection conDataBase = new MySqlConnection(constring);
            MySqlCommand cmdDataBase = new MySqlCommand("select * from dentaldb.patient ;", conDataBase);

            try
            {
                MySqlDataAdapter sda = new MySqlDataAdapter();
                sda.SelectCommand = cmdDataBase;
                DataTable dbdataset = new DataTable();
                sda.Fill(dbdataset);
                BindingSource bSource = new BindingSource();

                bSource.DataSource = dbdataset;
                dataGridView3.DataSource = bSource;
                sda.Update(dbdataset);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            */
        
        }

        private void dataGridView3_CellClick_1(object sender, DataGridViewCellEventArgs e)
        {
            idid=int.Parse(dataGridView3.SelectedRows[0].Cells[0].Value.ToString());
            cintba.Text = dataGridView3.SelectedRows[0].Cells[1].Value.ToString();
            nomtba.Text = dataGridView3.SelectedRows[0].Cells[2].Value.ToString();
            prenomtba.Text = dataGridView3.SelectedRows[0].Cells[3].Value.ToString();
            dateTimePicker2.Text = dataGridView3.SelectedRows[0].Cells[5].Value.ToString();
            teltba.Text = dataGridView3.SelectedRows[0].Cells[6].Value.ToString();
            protba.Text = dataGridView3.SelectedRows[0].Cells[7].Value.ToString();
            adrtba.Text = dataGridView3.SelectedRows[0].Cells[8].Value.ToString();
            pbstba.Text = dataGridView3.SelectedRows[0].Cells[9].Value.ToString();
            anltba.Text = dataGridView3.SelectedRows[0].Cells[10].Value.ToString();
            alltba.Text = dataGridView3.SelectedRows[0].Cells[11].Value.ToString();
            saitba.Text = dataGridView3.SelectedRows[0].Cells[12].Value.ToString();
            plttba.Text = dataGridView3.SelectedRows[0].Cells[14].Value.ToString();



            int sex = (int)dataGridView3.SelectedRows[0].Cells[4].Value;
            int enc = (int)dataGridView3.SelectedRows[0].Cells[13].Value;

            if (sex == 1)
            {
                this.radioButton4.Checked = true;
            }
            else if (sex == 0)
            {
                this.radioButton3.Checked = true;
            }
            else
            {

            }
            
            if (enc == 1)
            {
                this.radioButton6.Checked = true;
            }
            else if (enc == 0)
            {
                this.radioButton5.Checked = true;
            }
            else
            {

            }
        }

        private void dataGridView3_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {

        }

        private void timelbl_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick_1(object sender, EventArgs e)
        {
            timelbl.Text = DateTime.Now.ToLongTimeString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form form = new compta();
            form.Show();
        }

        private void button23_Click(object sender, EventArgs e)
        {

            if (dataGridView3.SelectedRows.Count > 0)
            {
                int selectedIndex = dataGridView3.SelectedRows[0].Index;

                int Id_value = int.Parse(dataGridView3[0, selectedIndex].Value.ToString());
                Form form = new Addconsult(Id_value);
                form.ShowDialog();
            }
            
        }

       
       

        private void teltba_TextChanged(object sender, EventArgs e)
        {

        }

        private void button20_Click(object sender, EventArgs e)
        {
            //recherche par CIN

            string cin_rech = this.rech_pat_cin.Text;

            string constring = "datasource=localhost;port=3306;username=root;password=BITEme4789";
            MySqlConnection conDataBase = new MySqlConnection(constring);
            MySqlCommand cmdDataBase = new MySqlCommand("select * from dentaldb.patient where cin_pat='" + cin_rech + "' ;", conDataBase);

            try
            {
                MySqlDataAdapter sda = new MySqlDataAdapter();
                sda.SelectCommand = cmdDataBase;
                DataTable dbdataset = new DataTable();
                sda.Fill(dbdataset);
                BindingSource bSource = new BindingSource();

                bSource.DataSource = dbdataset;
                dataGridView3.DataSource = bSource;
                sda.Update(dbdataset);
                rech_pat_cin.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button25_Click(object sender, EventArgs e)
        {
            //recherche RDV par nom+prenom

            string nom_recherche = this.rech_pat_nom.Text;
            string prenom_recherche = this.rech_pat_pre.Text;


            string constring = "datasource=localhost;port=3306;username=root;password=BITEme4789";
            MySqlConnection conDataBase = new MySqlConnection(constring);
            MySqlCommand cmdDataBase = new MySqlCommand("select * from dentaldb.patient where nom_pat='" + nom_recherche + "' and prenom_pat='" + prenom_recherche + "' ;", conDataBase);

            try
            {
                MySqlDataAdapter sda = new MySqlDataAdapter();
                sda.SelectCommand = cmdDataBase;
                DataTable dbdataset = new DataTable();
                sda.Fill(dbdataset);
                BindingSource bSource = new BindingSource();

                bSource.DataSource = dbdataset;
                dataGridView3.DataSource = bSource;
                sda.Update(dbdataset);
                rech_pat_nom.Clear();
                rech_pat_pre.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button26_Click(object sender, EventArgs e)
        {
            Form form = new G_des_Actes();
            form.Show();
        }

        private void button27_Click(object sender, EventArgs e)
        {
            Form form = new Teeth();
            form.Show();
        }

        private void user_welcome_lbl_Click(object sender, EventArgs e)
        {

        }

        private void button10_Click_1(object sender, EventArgs e)
        {

            //modifier consultation

            if (dataGridView_aff_cons.SelectedRows.Count > 0)
            {
                int selectedIndex = dataGridView_aff_cons.SelectedRows[0].Index;

                int rowID = int.Parse(dataGridView_aff_cons[0, selectedIndex].Value.ToString());
                Form sm = new Editconsult(rowID);
                sm.ShowDialog();
            }
        }

        private void button22_Click(object sender, EventArgs e)
        {
            string constring = "datasource=localhost;port=3306;username=root;password=BITEme4789";
            MySqlConnection conDataBase = new MySqlConnection(constring);
            MySqlCommand cmdDataBase = new MySqlCommand("select C.id_consultation,C.DATE_CONSULTATION,C.DENT,A.libelle_acte,C.traitement,C.reduction,C.total_paye,C.reste_a_payer from dentaldb.consultation C,dentaldb.acte A where C.id_pat= '" + idid + "' and A.num_acte=C.num_acte  ;", conDataBase);

            try
            {
                MySqlDataAdapter sda = new MySqlDataAdapter();
                sda.SelectCommand = cmdDataBase;
                DataTable dbdataset = new DataTable();
                sda.Fill(dbdataset);
                BindingSource bSource = new BindingSource();

                bSource.DataSource = dbdataset;
                dataGridView_aff_cons.DataSource = bSource;
                sda.Update(dbdataset);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button27_Click_1(object sender, EventArgs e)
        {
            string constring = "datasource=localhost;port=3306;username=root;password=BITEme4789";
            MySqlConnection conDataBase = new MySqlConnection(constring);
            MySqlCommand cmdDataBase = new MySqlCommand("select  C.id_consultation,P.CIN_PAT,C.DATE_CONSULTATION,C.DENT,A.libelle_acte,C.traitement,C.reduction,C.total_paye,C.reste_a_payer from dentaldb.consultation C,dentaldb.acte A,dentaldb.patient P where A.num_acte=C.num_acte and P.ID_PAT=C.ID_PAT;", conDataBase);

            try
            {
                MySqlDataAdapter sda = new MySqlDataAdapter();
                sda.SelectCommand = cmdDataBase;
                DataTable dbdataset = new DataTable();
                sda.Fill(dbdataset);
                BindingSource bSource = new BindingSource();

                bSource.DataSource = dbdataset;
                dataGridView_aff_cons.DataSource = bSource;
                sda.Update(dbdataset);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button28_Click(object sender, EventArgs e)
        {

            string constring = "datasource=localhost;port=3306;username=root;password=BITEme4789";
            MySqlConnection conDataBase = new MySqlConnection(constring);
            MySqlCommand cmdDataBase = new MySqlCommand("select C.id_consultation,P.cin_pat,C.DATE_CONSULTATION,C.DENT,A.libelle_acte,C.traitement,C.reduction,C.total_paye,C.reste_a_payer from dentaldb.consultation C,dentaldb.acte A,dentaldb.patient P where C.reste_a_payer<>0  and A.num_acte=C.num_acte and  P.id_pat=C.id_pat ;", conDataBase);

            try
            {
                MySqlDataAdapter sda = new MySqlDataAdapter();
                sda.SelectCommand = cmdDataBase;
                DataTable dbdataset = new DataTable();
                sda.Fill(dbdataset);
                BindingSource bSource = new BindingSource();

                bSource.DataSource = dbdataset;
                dataGridView_aff_cons.DataSource = bSource;
                sda.Update(dbdataset);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button29_Click(object sender, EventArgs e)
        {
            DialogResult myResult;
            myResult = MessageBox.Show("Etes vous sur de vouloir supprimer cette consultation ?", "Delete Confirmation", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
            if (myResult == DialogResult.OK)
            {

                string constring = "datasource=localhost;port=3306;username=root;password=BITEme4789";

                if (dataGridView_aff_cons.SelectedRows.Count > 0)
                {
                    int selectedIndex = dataGridView_aff_cons.SelectedRows[0].Index;

                    // gets the RowID from the first column in the grid
                    int rowID = int.Parse(dataGridView_aff_cons[0, selectedIndex].Value.ToString());

                    string sql = "DELETE FROM dentaldb.consultation WHERE id_consultation=" + rowID + ";";
                    MySqlConnection conDataBase = new MySqlConnection(constring);
                    MySqlCommand cmdDataBase = new MySqlCommand(sql, conDataBase);
                    MySqlDataReader myReader;
                    try
                    {
                        conDataBase.Open();
                        myReader = cmdDataBase.ExecuteReader();
                        MessageBox.Show("Consultation supprimée !! ");
                        while (myReader.Read())
                        { }
                    }
                    catch (Exception ex)
                    { MessageBox.Show(ex.Message); }

                    dataGridView_aff_cons.Rows.RemoveAt(this.dataGridView_aff_cons.SelectedRows[0].Index);
                }
            }
            else
            {
                //No delete
            }
        }

        private void dataGridView_aff_cons_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        }
    }

