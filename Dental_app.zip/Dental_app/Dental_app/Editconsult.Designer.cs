﻿namespace Dental_app
{
    partial class Editconsult
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.button27 = new System.Windows.Forms.Button();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.comboAct_therap_ed = new System.Windows.Forms.ComboBox();
            this.dateTimePicker1_ed = new System.Windows.Forms.DateTimePicker();
            this.button23 = new System.Windows.Forms.Button();
            this.traitement_ed = new System.Windows.Forms.TextBox();
            this.dent_ed = new System.Windows.Forms.TextBox();
            this.id_pat_vis_ed = new System.Windows.Forms.TextBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.nouv_paye_ed = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.button22 = new System.Windows.Forms.Button();
            this.reste_ed = new System.Windows.Forms.TextBox();
            this.total_paye_ed = new System.Windows.Forms.TextBox();
            this.total_a_payer_ed = new System.Windows.Forms.TextBox();
            this.reduction_ed = new System.Windows.Forms.TextBox();
            this.groupBox6.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.button27);
            this.groupBox6.Controls.Add(this.label26);
            this.groupBox6.Controls.Add(this.label25);
            this.groupBox6.Controls.Add(this.label24);
            this.groupBox6.Controls.Add(this.label23);
            this.groupBox6.Controls.Add(this.label22);
            this.groupBox6.Controls.Add(this.comboAct_therap_ed);
            this.groupBox6.Controls.Add(this.dateTimePicker1_ed);
            this.groupBox6.Controls.Add(this.button23);
            this.groupBox6.Controls.Add(this.traitement_ed);
            this.groupBox6.Controls.Add(this.dent_ed);
            this.groupBox6.Controls.Add(this.id_pat_vis_ed);
            this.groupBox6.Controls.Add(this.groupBox7);
            this.groupBox6.Location = new System.Drawing.Point(23, 25);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(969, 400);
            this.groupBox6.TabIndex = 2;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Nouvelle consultation";
            // 
            // button27
            // 
            this.button27.Image = global::Dental_app.Properties.Resources.Healthcare_False_Teeth_icon1;
            this.button27.Location = new System.Drawing.Point(248, 122);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(46, 45);
            this.button27.TabIndex = 12;
            this.button27.UseVisualStyleBackColor = true;
            this.button27.Click += new System.EventHandler(this.button27_Click);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(24, 228);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(99, 13);
            this.label26.TabIndex = 11;
            this.label26.Text = "Traitement effectué";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(31, 179);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(91, 13);
            this.label25.TabIndex = 10;
            this.label25.Text = "Act thérapetique :";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(31, 138);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(36, 13);
            this.label24.TabIndex = 9;
            this.label24.Text = "Dent :";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(27, 95);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(96, 13);
            this.label23.TabIndex = 8;
            this.label23.Text = "Date consultation :";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(31, 49);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(58, 13);
            this.label22.TabIndex = 7;
            this.label22.Text = "Id Patient :";
            // 
            // comboAct_therap_ed
            // 
            this.comboAct_therap_ed.FormattingEnabled = true;
            this.comboAct_therap_ed.Location = new System.Drawing.Point(145, 176);
            this.comboAct_therap_ed.Name = "comboAct_therap_ed";
            this.comboAct_therap_ed.Size = new System.Drawing.Size(222, 21);
            this.comboAct_therap_ed.TabIndex = 6;
            // 
            // dateTimePicker1_ed
            // 
            this.dateTimePicker1_ed.CustomFormat = "yyyy-MM-dd";
            this.dateTimePicker1_ed.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker1_ed.Location = new System.Drawing.Point(145, 89);
            this.dateTimePicker1_ed.Name = "dateTimePicker1_ed";
            this.dateTimePicker1_ed.Size = new System.Drawing.Size(222, 20);
            this.dateTimePicker1_ed.TabIndex = 5;
            // 
            // button23
            // 
            this.button23.Location = new System.Drawing.Point(507, 303);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(171, 53);
            this.button23.TabIndex = 4;
            this.button23.Text = "Modifier Consultation";
            this.button23.UseVisualStyleBackColor = true;
            this.button23.Click += new System.EventHandler(this.button23_Click);
            // 
            // traitement_ed
            // 
            this.traitement_ed.Location = new System.Drawing.Point(145, 225);
            this.traitement_ed.Multiline = true;
            this.traitement_ed.Name = "traitement_ed";
            this.traitement_ed.Size = new System.Drawing.Size(222, 131);
            this.traitement_ed.TabIndex = 3;
            // 
            // dent_ed
            // 
            this.dent_ed.Location = new System.Drawing.Point(145, 135);
            this.dent_ed.Name = "dent_ed";
            this.dent_ed.Size = new System.Drawing.Size(97, 20);
            this.dent_ed.TabIndex = 2;
            // 
            // id_pat_vis_ed
            // 
            this.id_pat_vis_ed.Location = new System.Drawing.Point(145, 46);
            this.id_pat_vis_ed.Name = "id_pat_vis_ed";
            this.id_pat_vis_ed.Size = new System.Drawing.Size(222, 20);
            this.id_pat_vis_ed.TabIndex = 1;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.label2);
            this.groupBox7.Controls.Add(this.label1);
            this.groupBox7.Controls.Add(this.nouv_paye_ed);
            this.groupBox7.Controls.Add(this.label34);
            this.groupBox7.Controls.Add(this.label33);
            this.groupBox7.Controls.Add(this.label32);
            this.groupBox7.Controls.Add(this.label31);
            this.groupBox7.Controls.Add(this.label30);
            this.groupBox7.Controls.Add(this.label29);
            this.groupBox7.Controls.Add(this.label28);
            this.groupBox7.Controls.Add(this.label27);
            this.groupBox7.Controls.Add(this.button22);
            this.groupBox7.Controls.Add(this.reste_ed);
            this.groupBox7.Controls.Add(this.total_paye_ed);
            this.groupBox7.Controls.Add(this.total_a_payer_ed);
            this.groupBox7.Controls.Add(this.reduction_ed);
            this.groupBox7.Location = new System.Drawing.Point(419, 24);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(527, 249);
            this.groupBox7.TabIndex = 0;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Payement";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(272, 141);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(103, 13);
            this.label2.TabIndex = 22;
            this.label2.Text = "Nouveau paiement :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(489, 141);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(26, 13);
            this.label1.TabIndex = 21;
            this.label1.Text = "Dhs";
            // 
            // nouv_paye_ed
            // 
            this.nouv_paye_ed.Location = new System.Drawing.Point(383, 138);
            this.nouv_paye_ed.Name = "nouv_paye_ed";
            this.nouv_paye_ed.Size = new System.Drawing.Size(95, 20);
            this.nouv_paye_ed.TabIndex = 20;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(272, 192);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(26, 13);
            this.label34.TabIndex = 19;
            this.label34.Text = "Dhs";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(234, 141);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(26, 13);
            this.label33.TabIndex = 18;
            this.label33.Text = "Dhs";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(272, 90);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(26, 13);
            this.label32.TabIndex = 17;
            this.label32.Text = "Dhs";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(272, 47);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(15, 13);
            this.label31.TabIndex = 16;
            this.label31.Text = "%";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(20, 192);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(79, 13);
            this.label30.TabIndex = 15;
            this.label30.Text = "Reste à payer :";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(20, 141);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(63, 13);
            this.label29.TabIndex = 14;
            this.label29.Text = "Total payé :";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(20, 90);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(75, 13);
            this.label28.TabIndex = 13;
            this.label28.Text = "Total à payer :";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(20, 47);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(99, 13);
            this.label27.TabIndex = 12;
            this.label27.Text = "Taux de réduction :";
            // 
            // button22
            // 
            this.button22.Location = new System.Drawing.Point(319, 187);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(85, 23);
            this.button22.TabIndex = 5;
            this.button22.Text = "Calculer";
            this.button22.UseVisualStyleBackColor = true;
            this.button22.Click += new System.EventHandler(this.button22_Click);
            // 
            // reste_ed
            // 
            this.reste_ed.Location = new System.Drawing.Point(131, 189);
            this.reste_ed.Name = "reste_ed";
            this.reste_ed.Size = new System.Drawing.Size(138, 20);
            this.reste_ed.TabIndex = 3;
            // 
            // total_paye_ed
            // 
            this.total_paye_ed.Location = new System.Drawing.Point(131, 138);
            this.total_paye_ed.Name = "total_paye_ed";
            this.total_paye_ed.Size = new System.Drawing.Size(95, 20);
            this.total_paye_ed.TabIndex = 2;
            // 
            // total_a_payer_ed
            // 
            this.total_a_payer_ed.Location = new System.Drawing.Point(131, 87);
            this.total_a_payer_ed.Name = "total_a_payer_ed";
            this.total_a_payer_ed.Size = new System.Drawing.Size(138, 20);
            this.total_a_payer_ed.TabIndex = 1;
            // 
            // reduction_ed
            // 
            this.reduction_ed.Location = new System.Drawing.Point(131, 44);
            this.reduction_ed.Name = "reduction_ed";
            this.reduction_ed.Size = new System.Drawing.Size(138, 20);
            this.reduction_ed.TabIndex = 0;
            // 
            // Editconsult
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1014, 451);
            this.Controls.Add(this.groupBox6);
            this.Name = "Editconsult";
            this.Text = "Editconsult";
            this.Load += new System.EventHandler(this.Editconsult_Load);
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.ComboBox comboAct_therap_ed;
        private System.Windows.Forms.DateTimePicker dateTimePicker1_ed;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.TextBox traitement_ed;
        private System.Windows.Forms.TextBox dent_ed;
        private System.Windows.Forms.TextBox id_pat_vis_ed;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.TextBox reste_ed;
        private System.Windows.Forms.TextBox total_paye_ed;
        private System.Windows.Forms.TextBox total_a_payer_ed;
        private System.Windows.Forms.TextBox reduction_ed;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox nouv_paye_ed;

    }
}