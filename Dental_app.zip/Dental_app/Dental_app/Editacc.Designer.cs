﻿namespace Dental_app
{
    partial class Editacc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Ajouter = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.passmod = new System.Windows.Forms.TextBox();
            this.logmod = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Ajouter
            // 
            this.Ajouter.Location = new System.Drawing.Point(255, 317);
            this.Ajouter.Name = "Ajouter";
            this.Ajouter.Size = new System.Drawing.Size(118, 36);
            this.Ajouter.TabIndex = 9;
            this.Ajouter.Text = "Enregistrer";
            this.Ajouter.UseVisualStyleBackColor = true;
            this.Ajouter.Click += new System.EventHandler(this.Ajouter_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.passmod);
            this.groupBox1.Controls.Add(this.logmod);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Location = new System.Drawing.Point(73, 49);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(472, 232);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Modification des comptes";
            // 
            // passmod
            // 
            this.passmod.Location = new System.Drawing.Point(225, 148);
            this.passmod.Name = "passmod";
            this.passmod.Size = new System.Drawing.Size(136, 20);
            this.passmod.TabIndex = 5;
            // 
            // logmod
            // 
            this.logmod.Location = new System.Drawing.Point(225, 92);
            this.logmod.Name = "logmod";
            this.logmod.Size = new System.Drawing.Size(136, 20);
            this.logmod.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(98, 95);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(33, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Login";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(98, 151);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(71, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Mot de passe";
            // 
            // Editacc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(614, 401);
            this.Controls.Add(this.Ajouter);
            this.Controls.Add(this.groupBox1);
            this.Name = "Editacc";
            this.Text = "Editacc";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button Ajouter;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox passmod;
        private System.Windows.Forms.TextBox logmod;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;

    }
}