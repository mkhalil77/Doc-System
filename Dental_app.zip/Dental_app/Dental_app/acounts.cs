﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dental_app
{
    public partial class acounts : Form
    {
        public static int id5;
        public static int id6;
        public acounts()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            dataGridView1.AllowUserToAddRows = false;
            String constring = "datasource=localhost;port=3306;username=root;password=BITEme4789";
            MySqlConnection conDataBase = new MySqlConnection(constring);
            MySqlCommand cmdDataBase = new MySqlCommand("select * from dentaldb.auth ;", conDataBase);

            try
            {
                MySqlDataAdapter sda = new MySqlDataAdapter();
                sda.SelectCommand = cmdDataBase;
                DataTable dbdataset = new DataTable();
                sda.Fill(dbdataset);
                BindingSource bSource = new BindingSource();

                bSource.DataSource = dbdataset;
                dataGridView1.DataSource = bSource;
                sda.Update(dbdataset);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        private void button6_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                int selectedIndex1 = dataGridView1.SelectedRows[0].Index;

                int rowID1 = int.Parse(dataGridView1[0, selectedIndex1].Value.ToString());
            

                Editacc ea = new Editacc(rowID1);
                ea.ShowDialog();
            }
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            Addacc ac = new Addacc();
            ac.ShowDialog();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            //supprimer medecin

            if (dataGridView1.SelectedRows.Count > 0)
            {
                int selectedIndex = dataGridView1.SelectedRows[0].Index;

                int rowID = int.Parse(dataGridView1[0, selectedIndex].Value.ToString());
                id5 = rowID;
            }
            try
            {
                string myConnection2 = "datasource=localhost;port=3306;username=root;password=BITEme4789";
                string query2 = "delete from dentaldb.auth where idAuth='" + id5 + "'; ";


                MySqlConnection myConn2 = new MySqlConnection(myConnection2);
                MySqlCommand cmdDataBase2 = new MySqlCommand(query2, myConn2);
                MySqlDataReader myReader2;

                myConn2.Open();
                myReader2 = cmdDataBase2.ExecuteReader();

            }
            catch (Exception ex)
            { MessageBox.Show(ex.Message); }

            dataGridView1.Rows.RemoveAt(this.dataGridView1.SelectedRows[0].Index);
        }

}

}