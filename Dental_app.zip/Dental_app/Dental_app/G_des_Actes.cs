﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dental_app
{
    public partial class G_des_Actes : Form
    {
        public G_des_Actes()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //ajout acte

            try
            {
                string myConnection1 = "datasource=localhost;port=3306;username=root;password=BITEme4789";
                string query1 = "insert into dentaldb.acte values (0,'" + this.textBox1.Text + "'," + int.Parse(this.textBox2.Text) + ",'" + this.textBox3.Text + "');  ";

                // string query2 = "select max(id_pat) from cabinet_medical.patient where nom_pat='" + this.nv_rdv_nom.Text + "' and prenom_pat='" + this.nv_rdv_prenom.Text + "'; ";

                MySqlConnection myConn1 = new MySqlConnection(myConnection1);
                MySqlCommand cmdDataBase1 = new MySqlCommand(query1, myConn1);
                MySqlDataReader myReader1;

                myConn1.Open();
                myReader1 = cmdDataBase1.ExecuteReader();


                while (myReader1.Read()) { }
            }
            catch (Exception ex)
            { MessageBox.Show(ex.Message); }

            MessageBox.Show("Acte ajouté !!");

            string constring = "datasource=localhost;port=3306;username=root;password=BITEme4789";
            MySqlConnection conDataBase = new MySqlConnection(constring);
            MySqlCommand cmdDataBase = new MySqlCommand("select * from dentaldb.acte ;", conDataBase);

            try
            {
                MySqlDataAdapter sda = new MySqlDataAdapter();
                sda.SelectCommand = cmdDataBase;
                DataTable dbdataset = new DataTable();
                sda.Fill(dbdataset);
                BindingSource bSource = new BindingSource();

                bSource.DataSource = dbdataset;
                dataGridView1.DataSource = bSource;
                sda.Update(dbdataset);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            // mise a jour acte
            if (dataGridView1.SelectedRows.Count > 0)
            {
                int selectedIndex = dataGridView1.SelectedRows[0].Index;

                // gets the RowID from the first column in the grid
                int rowID = int.Parse(dataGridView1[0, selectedIndex].Value.ToString());


                string constring = "datasource=localhost;port=3306;username=root;password=BITEme4789";
                string sql = "update dentaldb.acte set libelle_acte='" + this.textBox1.Text + "',prix_acte='" + this.textBox2.Text + "' ,cotation='" + this.textBox3.Text + "' where num_acte=" + rowID + "  ;";
                MySqlConnection conDataBase = new MySqlConnection(constring);
                MySqlCommand cmdDataBase = new MySqlCommand(sql, conDataBase);
                MySqlDataReader myReader;
                try
                {
                    conDataBase.Open();
                    myReader = cmdDataBase.ExecuteReader();
                    MessageBox.Show("acte mis à jour !! ");
                    while (myReader.Read())
                    { }
                }

                catch (Exception ex)
                { MessageBox.Show(ex.Message); }

            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // supprimer acte 


            DialogResult myResult;
            myResult = MessageBox.Show("Etes vous sur de vouloir supprimer cet acte?", "Delete Confirmation", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
            if (myResult == DialogResult.OK)
            {

                string constring = "datasource=localhost;port=3306;username=root;password=BITEme4789";

                if (dataGridView1.SelectedRows.Count > 0)
                {
                    int selectedIndex = dataGridView1.SelectedRows[0].Index;

                    // gets the RowID from the first column in the grid
                    int rowID = int.Parse(dataGridView1[0, selectedIndex].Value.ToString());

                    string sql = "DELETE FROM dentaldb.acte WHERE num_acte=" + rowID + ";";
                    MySqlConnection conDataBase = new MySqlConnection(constring);
                    MySqlCommand cmdDataBase = new MySqlCommand(sql, conDataBase);
                    MySqlDataReader myReader;
                    try
                    {
                        conDataBase.Open();
                        myReader = cmdDataBase.ExecuteReader();
                        MessageBox.Show("Acte supprimé !! ");
                        while (myReader.Read())
                        { }
                    }
                    catch (Exception ex)
                    { MessageBox.Show(ex.Message); }

                    dataGridView1.Rows.RemoveAt(this.dataGridView1.SelectedRows[0].Index);
                }


            }
            else
            {
                //No delete
            }

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            textBox1.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            textBox2.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
            textBox3.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string constring = "datasource=localhost;port=3306;username=root;password=BITEme4789";
            MySqlConnection conDataBase = new MySqlConnection(constring);
            MySqlCommand cmdDataBase = new MySqlCommand("select * from dentaldb.acte ;", conDataBase);

            try
            {
                MySqlDataAdapter sda = new MySqlDataAdapter();
                sda.SelectCommand = cmdDataBase;
                DataTable dbdataset = new DataTable();
                sda.Fill(dbdataset);
                BindingSource bSource = new BindingSource();

                bSource.DataSource = dbdataset;
                dataGridView1.DataSource = bSource;
                sda.Update(dbdataset);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
    }
}
