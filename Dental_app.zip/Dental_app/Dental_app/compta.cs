﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dental_app
{
    public partial class compta : Form
    {
        private String debut;
        private String fin;
        private float entree = 0;
        private float sortie = 0;
        private float gain;

        private String charge;
        private int id_charge;

        public compta()
        {
            InitializeComponent();
            FillCombo();
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // calcul montant 

            debut = dateTimePicker1.Text;
            fin = dateTimePicker2.Text;



            try
            {
                string myConnection2 = "datasource=localhost;port=3306;username=root;password=BITEme4789";
                string query2 = "select * from dentaldb.consultation where date_consultation >='" + debut + "' and date_consultation <= '" + fin + "'   ; ";

                MySqlConnection myConn2 = new MySqlConnection(myConnection2);
                MySqlCommand cmdDataBase2 = new MySqlCommand(query2, myConn2);
                MySqlDataReader myReader2;

                myConn2.Open();
                myReader2 = cmdDataBase2.ExecuteReader();


                while (myReader2.Read())
                {
                    entree += (float)myReader2["total_paye"];
                }

                textBox1.Text = entree.ToString();

            }
            catch (Exception ex)
            { MessageBox.Show(ex.Message); }


            try
            {
                string myConnection2 = "datasource=localhost;port=3306;username=root;password=BITEme4789";
                string query2 = "select * from dentaldb.charge C, dentaldb.charge_usuelle CU where C.date_charge >='" + debut + "' and C.date_charge <= '" + fin + "' and C.id_charge_us=CU.id_charge_us ; ";

                MySqlConnection myConn2 = new MySqlConnection(myConnection2);
                MySqlCommand cmdDataBase2 = new MySqlCommand(query2, myConn2);
                MySqlDataReader myReader2;

                myConn2.Open();
                myReader2 = cmdDataBase2.ExecuteReader();


                while (myReader2.Read())
                {
                    sortie += (float)myReader2["MONTANT_CHARGE"];
                }

                textBox2.Text = sortie.ToString();

            }
            catch (Exception ex)
            { MessageBox.Show(ex.Message); }

            gain = entree - sortie;
            textBox3.Text = gain.ToString();

        }

        void FillCombo()
        {
            string myConnection2 = "datasource=localhost;port=3306;username=root;password=BITEme4789";
            string query2 = "select * from dentaldb.charge_usuelle ; ";

            try
            {

                MySqlConnection myConn2 = new MySqlConnection(myConnection2);
                MySqlCommand cmdDataBase2 = new MySqlCommand(query2, myConn2);
                MySqlDataReader myReader2;

                myConn2.Open();
                myReader2 = cmdDataBase2.ExecuteReader();


                while (myReader2.Read())
                {

                    charge = myReader2.GetString("LIBELLE_CHARGE");
                    comboBox1.Items.Add(charge);
                }

            }

            catch (Exception ex)
            { MessageBox.Show(ex.Message); }

        }

        
       
        private void button8_Click(object sender, EventArgs e)
        {
            string constring = "datasource=localhost;port=3306;username=root;password=BITEme4789";
            MySqlConnection conDataBase = new MySqlConnection(constring);
            MySqlCommand cmdDataBase = new MySqlCommand("select C.id_charge,CU.libelle_charge,CU.montant_charge,C.date_charge from dentaldb.charge C,dentaldb.charge_usuelle CU where C.id_charge_us=CU.id_charge_us ;", conDataBase);

            try
            {
                MySqlDataAdapter sda = new MySqlDataAdapter();
                sda.SelectCommand = cmdDataBase;
                DataTable dbdataset = new DataTable();
                sda.Fill(dbdataset);
                BindingSource bSource = new BindingSource();

                bSource.DataSource = dbdataset;
                dataGridView2.DataSource = bSource;
                sda.Update(dbdataset);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void button7_Click(object sender, EventArgs e)
        {
            // calculer montant_charge

            try
            {
                string myConnection = "datasource=localhost;port=3306;username=root;password=BITEme4789";
                string query = "select * from dentaldb.charge_usuelle  where libelle_charge='" + comboBox1.Text + "' ; ";


                MySqlConnection myConn = new MySqlConnection(myConnection);
                MySqlCommand cmdDataBase = new MySqlCommand(query, myConn);
                MySqlDataReader myReader;

                myConn.Open();
                myReader = cmdDataBase.ExecuteReader();


                while (myReader.Read())
                {
                    this.textBox6.Text = myReader["MONTANT_CHARGE"].ToString();
                }

            }

            catch (Exception ex)
            { MessageBox.Show(ex.Message); }

        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                string myConnection1 = "datasource=localhost;port=3306;username=root;password=BITEme4789";
                string query1 = "select * from dentaldb.charge_usuelle  where libelle_charge='" + comboBox1.Text + "' ; ";


                MySqlConnection myConn1 = new MySqlConnection(myConnection1);
                MySqlCommand cmdDataBase1 = new MySqlCommand(query1, myConn1);
                MySqlDataReader myReader1;

                myConn1.Open();
                myReader1 = cmdDataBase1.ExecuteReader();


                while (myReader1.Read())
                {
                    id_charge = Int16.Parse(myReader1.GetString("ID_CHARGE_US"));
                }

            }

            catch (Exception ex)
            { MessageBox.Show(ex.Message); }

            try
            {
                string myConnection1 = "datasource=localhost;port=3306;username=root;password=BITEme4789";
                string query1 = "insert into dentaldb.charge values (0,'" + this.id_charge + "','" + this.dateTimePicker3.Text + "' );  ";

                // string query2 = "select max(id_pat) from cabinet_medical.patient where nom_pat='" + this.nv_rdv_nom.Text + "' and prenom_pat='" + this.nv_rdv_prenom.Text + "'; ";

                MySqlConnection myConn1 = new MySqlConnection(myConnection1);
                MySqlCommand cmdDataBase1 = new MySqlCommand(query1, myConn1);
                MySqlDataReader myReader1;

                myConn1.Open();
                myReader1 = cmdDataBase1.ExecuteReader();

                while (myReader1.Read()) { }
            }
            catch (Exception ex1)
            { MessageBox.Show(ex1.Message); }

            MessageBox.Show("Charge ajoutée avec succès !! ");

        }

        private void button6_Click(object sender, EventArgs e)
        {
            // supprimer charge 

            DialogResult myResult;
            myResult = MessageBox.Show("Etes vous sur de vouloir supprimer cete charge?", "Delete Confirmation", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
            if (myResult == DialogResult.OK)
            {

                string constring = "datasource=localhost;port=3306;username=root;password=BITEme4789";

                if (dataGridView2.SelectedRows.Count > 0)
                {
                    int selectedIndex = dataGridView2.SelectedRows[0].Index;

                    // gets the RowID from the first column in the grid
                    int rowID = int.Parse(dataGridView2[0, selectedIndex].Value.ToString());

                    string sql = "DELETE FROM dentaldb.charge WHERE id_charge=" + rowID + ";";
                    MySqlConnection conDataBase = new MySqlConnection(constring);
                    MySqlCommand cmdDataBase = new MySqlCommand(sql, conDataBase);
                    MySqlDataReader myReader;
                    try
                    {
                        conDataBase.Open();
                        myReader = cmdDataBase.ExecuteReader();
                        MessageBox.Show("Charge supprimée !! ");
                        while (myReader.Read())
                        { }
                    }
                    catch (Exception ex)
                    { MessageBox.Show(ex.Message); }

                    dataGridView2.Rows.RemoveAt(this.dataGridView2.SelectedRows[0].Index);
                }


            }
            else
            {
                //No delete
            }

        }

        private void button9_Click(object sender, EventArgs e)
        {
            Form form = new Ajout_charges_fix();
            form.Show();
        }
    }
}
