﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Dental_app
{
    public partial class mofpat : Form
    {
        public static int id2;
        public mofpat(int id)
        {
            id2 = id;
            InitializeComponent();
            
            try
            {
                string myConnection2 = "datasource=localhost;port=3306;username=root;password=BITEme4789";
                string query2 = "select * from dentaldb.patient where ID_PAT='" + id + "'; ";



                MySqlConnection myConn2 = new MySqlConnection(myConnection2);
                MySqlCommand cmdDataBase2 = new MySqlCommand(query2, myConn2);
                MySqlDataReader myReader2;

                myConn2.Open();
                myReader2 = cmdDataBase2.ExecuteReader();


                while (myReader2.Read())
                {

                    cintbm.Text = (string)myReader2["CIN_PAT"];
                    nomtbm.Text = (string)myReader2["NOM_PAT"];
                    prenomtbm.Text = (string)myReader2["PRENOM_PAT"];
                    DateTime ddn = (DateTime)myReader2["DATE_N_PAT"];
                    dateTimePicker1.Text = ddn.ToString("yyyy-MM-dd");
                    teltbm.Text = (string)myReader2["NUM_TEL_PAT"];
                    protbm.Text = (string)myReader2["PROF_PAT"];
                    adrtbm.Text = (string)myReader2["ADRESSE_PAT"];
                    pbstbm.Text = (string)myReader2["PROB_SANTE"];
                    anltbm.Text = (string)myReader2["ANES_LOCALE"];
                    alltbm.Text = (string)myReader2["ALLERGIE"];
                    saitbm.Text = (string)myReader2["SAIGNE"];
                    plttbm.Text = (string)myReader2["PLAN_TRAIT"];
                    int sex = (int)myReader2["SEXE_PAT"];
                    if (sex == 1) {
                        this.radioButton1.Checked = true;
                    }
                    if (sex == 0 ) {
                        this.radioButton2.Checked = true;
                    }
                    int enc = (int)myReader2["ENCEINTE"];
                    if (enc == 1)
                    {
                        this.radioButton3.Checked = true;
                    }
                    if (enc == 0)
                    {
                        this.radioButton4.Checked = true;
                    }
                    
                }
            }
            catch (Exception ex)
            { MessageBox.Show(ex.Message); }


        }

        int gender;
        int enc;
        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            string constring = "datasource=localhost;port=3306;username=root;password=BITEme4789";
            string Query = "update dentaldb.patient set CIN_PAT='" + this.cintbm.Text + "',NOM_PAT='" + this.nomtbm.Text + "',PRENOM_PAT='" + this.prenomtbm.Text + "',DATE_N_PAT='" + this.dateTimePicker1.Text + "',NUM_TEL_PAT='" + this.teltbm.Text + "',PROF_PAT='" + this.protbm.Text + "',ADRESSE_PAT='" + this.adrtbm.Text + "',PROB_SANTE='" + this.pbstbm.Text + "',ANES_LOCALE='" + this.anltbm.Text + "',ALLERGIE='" + this.alltbm.Text + "',SAIGNE='" + this.saitbm.Text + "',PLAN_TRAIT='" + this.plttbm.Text + "',SEXE_PAT='" + gender + "',ENCEINTE='" + enc + "' where ID_PAT= " + id2 + " ;";
            MySqlConnection conDataBase = new MySqlConnection(constring);
            MySqlCommand cmdDataBase = new MySqlCommand(Query, conDataBase);
            MySqlDataReader myReader;
            try
            {
                conDataBase.Open();
                myReader = cmdDataBase.ExecuteReader();
                MessageBox.Show("Saved");
                this.Hide();
                while (myReader.Read())
                {

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            gender = 1;
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            gender = 0;
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            enc = 1;
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            enc = 0;
        }

        private void cintb_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
