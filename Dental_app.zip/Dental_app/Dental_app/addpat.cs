﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Dental_app
{
    public partial class addpat : Form
    {
        public addpat()
        {
            InitializeComponent();
        }

        int gender;
        int enc;
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string constring = "datasource=localhost;port=3306;username=root;password=BITEme4789";
            string Query = "insert into dentaldb.patient (CIN_PAT,NOM_PAT,PRENOM_PAT,DATE_N_PAT,NUM_TEL_PAT,PROF_PAT,ADRESSE_PAT,PROB_SANTE,ANES_LOCALE,ALLERGIE,SAIGNE,PLAN_TRAIT,SEXE_PAT,ENCEINTE) values('" + this.cintb.Text + "','" + this.nomtb.Text + "','" + this.prenomtb.Text + "','" + this.dateTimePicker1.Text + "','" + this.teltb.Text + "','" + this.protb.Text + "','" + this.adrtb.Text + "','" + this.pbstb.Text + "','" + this.anltb.Text + "','" + this.alltb.Text + "','" + this.saitb.Text + "','" + this.plttb.Text + "','" + gender + "','" + enc + "');";
            MySqlConnection conDataBase = new MySqlConnection(constring);
            MySqlCommand cmdDataBase = new MySqlCommand(Query, conDataBase);
            MySqlDataReader myReader;
            try
            {
                conDataBase.Open();
                myReader = cmdDataBase.ExecuteReader();
                MessageBox.Show("Saved");
                this.Hide();
                while (myReader.Read()) { 
                
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            gender = 1;
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            gender = 0;
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            enc = 1;
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            enc = 0;
        }
    }
}
