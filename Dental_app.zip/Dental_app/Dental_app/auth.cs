﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Dental_app
{
    public partial class auth : Form
    {
        public static string srt;
        public auth()
        {
            InitializeComponent();
            uname_text.MaxLength = 10;
            pass_text.MaxLength = 10;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                String myConnection = "datasource=localhost;port=3306;username=root;password=BITEme4789";
                MySqlConnection myConn = new MySqlConnection(myConnection);
                MySqlDataAdapter myDataAdapter = new MySqlDataAdapter();
                myDataAdapter.SelectCommand = new MySqlCommand("select * from dentaldb.auth;",myConn);
                MySqlCommandBuilder cb = new MySqlCommandBuilder(myDataAdapter);
                myConn.Open();
                //DataSet ds = new DataSet();
                MessageBox.Show("Connected");
                myConn.Close();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                String myConnection = "datasource=localhost;port=3306;username=root;password=BITEme4789";
                MySqlConnection myConn = new MySqlConnection(myConnection);

                MySqlCommand SelectCommand = new MySqlCommand("select * from dentaldb.auth where user_name='"+ this.uname_text.Text + "' and password='"+ this.pass_text.Text +"' and Type = '" + comboBox1.Text + "' ;", myConn);
                MySqlDataReader myReader;
                myConn.Open();
                myReader = SelectCommand.ExecuteReader();
                int count = 0;
                while(myReader.Read())
                {
                    count = count + 1;
                }
                if (count == 1)
                {
                    
                    MessageBox.Show("Username and password are correct");
                    this.Hide();
                    
                    if (comboBox1.Text == "MEDECIN")
                    {
                        Main ss = new Main(uname_text.Text);
                        ss.ShowDialog();
                    }
                    if (comboBox1.Text == "SECRETAIRE")
                    {
                        Main1 ss = new Main1(uname_text.Text);
                        ss.ShowDialog();
                    }
                }
                else if (count > 1)
                {
                    MessageBox.Show("Duplicate Username and password access denied");
                }
                else
                    MessageBox.Show("Login ou mot de passe est incorrecte .. réessayez");
                
                myConn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }


        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pass_text_TextChanged(object sender, EventArgs e)
        {
        
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
