﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dental_app
{
    public partial class Ajouter_RDV : Form
    {
        private int id_pat;
        private string cin_pat;
        private string date_rdv;
        private string heure_rdv;

        public Ajouter_RDV(string rdv_value)
        {
            InitializeComponent();

            textBox1.Text = rdv_value.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //ajouter RDV 

            cin_pat = textBox1.Text;



            try
            {   // verfifier l'existance du patient 
                string myConnection2 = "datasource=localhost;port=3306;username=root;password=BITEme4789";
                string query2 = "select * from dentaldb.patient where cin_pat='" + cin_pat + "' ; ";

                MySqlConnection myConn2 = new MySqlConnection(myConnection2);
                MySqlCommand cmdDataBase2 = new MySqlCommand(query2, myConn2);
                MySqlDataReader myReader2;

                myConn2.Open();
                myReader2 = cmdDataBase2.ExecuteReader();


                if (myReader2.Read())
                {     // patient existe 

                    int boolean = 0;

                    date_rdv = this.dateTimePicker1.Text;
                    heure_rdv = this.dateTimePicker2.Text;
                    //   com = this.textBox3.Text;

                    // MessageBox.Show(heure_rdv);



                    try
                    {
                        string myConnection3 = "datasource=localhost;port=3306;username=root;password=BITEme4789";
                        string query3 = "select date_rdv,heure_rdv from dentaldb.rdv; ";

                        MySqlConnection myConn3 = new MySqlConnection(myConnection3);
                        MySqlCommand cmdDataBase3 = new MySqlCommand(query3, myConn3);
                        MySqlDataReader myReader3;

                        myConn3.Open();
                        myReader3 = cmdDataBase3.ExecuteReader();


                        while (myReader3.Read() && boolean == 0)
                        {

                            DateTime date_lue = (DateTime)myReader3["date_rdv"];
                            string date_convertie = date_lue.ToString("yyyy-MM-dd");


                            if (date_rdv.Equals(date_convertie) && heure_rdv.Equals((string)myReader3["heure_rdv"]))
                            { boolean = 1; }

                        }

                    }
                    catch (Exception ex)
                    { MessageBox.Show(ex.Message); }


                    if (boolean == 1)  // date deja prise!!

                    { MessageBox.Show("Entrer une autre date, ce RDv est déja pris !!"); }

                    else
                    {    // date OK!!
                        id_pat = (int)myReader2["id_pat"];

                        try
                        {

                            string myConnection3 = "datasource=localhost;port=3306;username=root;password=BITEme4789";
                            string query3 = "insert into dentaldb.rdv values (0," + id_pat + ",'" + this.dateTimePicker1.Text + "','" + this.dateTimePicker2.Text + "','" + this.textBox3.Text + "');";

                            MySqlConnection myConn3 = new MySqlConnection(myConnection3);
                            MySqlCommand cmdDataBase3 = new MySqlCommand(query3, myConn3);
                            MySqlDataReader myReader3;

                            myConn3.Open();
                            myReader3 = cmdDataBase3.ExecuteReader();
                            MessageBox.Show("RDV ajouté avec succès!!");
                            this.Hide();
                            while (myReader3.Read()) { }

                        }
                        catch (Exception ex1)
                        { MessageBox.Show(ex1.Message); }

                    }

                }

                else
                { MessageBox.Show("ce patient ne figure pas dans notre liste !"); }



            }
            catch (Exception ex2)
            { MessageBox.Show(ex2.Message); }
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        }
    }
