﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dental_app
{
    
    public partial class Editconsult : Form
    {
        public static int id3;
        private float taux_reduction = 0f;
        private float prix_acte;
        
        public Editconsult(int id)
        {
            id3 = id;
            InitializeComponent();

            try
            {
                string myConnection2 = "datasource=localhost;port=3306;username=root;password=BITEme4789";
                string query2 = "select * from dentaldb.consultation where ID_CONSULTATION='" + id + "'; ";



                MySqlConnection myConn2 = new MySqlConnection(myConnection2);
                MySqlCommand cmdDataBase2 = new MySqlCommand(query2, myConn2);
                MySqlDataReader myReader2;

                myConn2.Open();
                myReader2 = cmdDataBase2.ExecuteReader();


                while (myReader2.Read())
                {

                    id_pat_vis_ed.Text = myReader2["ID_PAT"].ToString();
                    DateTime ddn = (DateTime)myReader2["DATE_CONSULTATION"];
                    dateTimePicker1_ed.Text = ddn.ToString("yyyy-MM-dd");
                    dent_ed.Text = myReader2["DENT"].ToString();


                    int dd = (int)myReader2["NUM_ACTE"];

                    try
                    {
                        string myConnection3 = "datasource=localhost;port=3306;username=root;password=BITEme4789";
                        string query3 = "select * from dentaldb.acte where NUM_ACTE='" + dd + "'; ";



                        MySqlConnection myConn3 = new MySqlConnection(myConnection3);
                        MySqlCommand cmdDataBase3 = new MySqlCommand(query3, myConn3);
                        MySqlDataReader myReader3;

                        myConn3.Open();
                        myReader3 = cmdDataBase3.ExecuteReader();


                        while (myReader3.Read())
                        {
                            comboAct_therap_ed.Text = myReader3["LIBELLE_ACTE"].ToString();
                        }
                    }
                        catch (Exception ex)
                        { MessageBox.Show(ex.Message); }



                    traitement_ed.Text = myReader2["TRAITEMENT"].ToString();
                    reduction_ed.Text = myReader2["REDUCTION"].ToString();
                    total_paye_ed.Text = myReader2["TOTAL_PAYE"].ToString();
                    reste_ed.Text = myReader2["RESTE_A_PAYER"].ToString();
                    
                    
                }
            }
            catch (Exception ex)
            { MessageBox.Show(ex.Message); }


        }

        private void button23_Click(object sender, EventArgs e)
        {

            float nv_tot_pay = float.Parse(this.total_paye_ed.Text) + float.Parse(this.nouv_paye_ed.Text);

            
            string constring = "datasource=localhost;port=3306;username=root;password=BITEme4789";
            string Query = "update dentaldb.consultation set RESTE_A_PAYER ='" + this.reste_ed.Text + "',TOTAL_PAYE ='" + nv_tot_pay + "' where ID_CONSULTATION = " + id3 + " ;";
            MySqlConnection conDataBase = new MySqlConnection(constring);
            MySqlCommand cmdDataBase = new MySqlCommand(Query, conDataBase);
            MySqlDataReader myReader;
            try
            {
                conDataBase.Open();
                myReader = cmdDataBase.ExecuteReader();
                MessageBox.Show("Saved");
                this.Hide();
                while (myReader.Read())
                {

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button22_Click(object sender, EventArgs e)
        {
            //calculer reste 

            float prix = float.Parse(this.reste_ed.Text) - float.Parse(this.nouv_paye_ed.Text);

            this.reste_ed.Text = prix.ToString();

        }

        private void Editconsult_Load(object sender, EventArgs e)
        {
            id_pat_vis_ed.ReadOnly = true;
            this.dateTimePicker1_ed.Enabled = false;
            dent_ed.ReadOnly = true;
            traitement_ed.ReadOnly = true;
            reduction_ed.ReadOnly = true;

            // calcul total 

            this.taux_reduction = float.Parse(reduction_ed.Text);
            

            try
            {
                string myConnection = "datasource=localhost;port=3306;username=root;password=BITEme4789";
                string query = "select * from dentaldb.acte  where libelle_acte='" + comboAct_therap_ed.Text + "' ; ";


                MySqlConnection myConn = new MySqlConnection(myConnection);
                MySqlCommand cmdDataBase = new MySqlCommand(query, myConn);
                MySqlDataReader myReader;

                myConn.Open();
                myReader = cmdDataBase.ExecuteReader();


                while (myReader.Read())
                {
                    this.prix_acte = float.Parse(myReader.GetString("PRIX_ACTE"));
                }

            }

            catch (Exception ex)
            { MessageBox.Show(ex.Message); }


            this.total_a_payer_ed.Text = (prix_acte - (prix_acte * taux_reduction / 100)).ToString();
        
        }

        private void button27_Click(object sender, EventArgs e)
        {
            Form form = new Teeth();
            form.Show();
        }
    }
}
